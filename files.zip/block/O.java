package block;

public class O extends Block {

	/**
	 * Construct a singleton block of the O tetromino
	 */
	public O() {
		super("block/O.png");
	}

}
