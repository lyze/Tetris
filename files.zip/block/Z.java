package block;

public class Z extends Block {

	/**
	 * Construct a singleton block of the Z tetromino
	 *
	 */
	public Z() {
		super("block/Z.png");
	}

}
