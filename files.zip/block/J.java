package block;

public class J extends Block {

	/**
	 * Construct a singleton block of the J tetromino
	 */
	public J() {
		super("block/J.png");
	}

}
