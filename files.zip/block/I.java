/**
 *
 */
package block;

/**
 * @author David Xu
 *
 */
public class I extends Block {

	/**
	 * Construct a singleton block of the I tetromino
	 */
	public I() {
		super("block/I.png");
	}

}
