package block;

public class S extends Block {

	/**
	 * Construct a singleton block of an S tetromino
	 */
	public S() {
		super("block/S.png");
	}

}
