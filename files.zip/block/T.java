package block;

public class T extends Block {

	/**
	 * Construct a singleton block of a T tetromino
	 *
	 */
	public T() {
		super("block/T.png");
	}

}
