package tetromino;
/**
 * This enum holds the different types of tetrominos.
 *
 * @author David Xu
 */
public enum Tetrominos {
	I, J, L, O, S, T, Z;
}